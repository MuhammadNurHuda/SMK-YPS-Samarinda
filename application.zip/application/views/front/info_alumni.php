<h1>Alumni</h1>
<hr>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="well">
<h2 class="text-center">Info Alumni</h2>
<p align="center">Untuk Seluruh Alumni SMK YPS Samarinda segera melakukan pendaftaran atau pendataan <br> Pendaftaran Alumni Smk Yps Samarinda Bisa melakukan registri melalui link dibawah ini</p>
<p align="center"><?php echo  anchor('alumni/daftar_alumni','Daftar Sekarang',array('class' => 'btn btn-primary btn-lg')) ?></p>
<p align="center">Untuk Melihat sudah terdaftar atau belum langsung saja hubungi Pak Teguh</p>
<?php echo $this->session->flashdata('msg'); ?>
</div>
</div>
</div>
</div>