<style type="text/css">
	#op{
		color: red;
		margin-top: 100px;
	}
</style>
<h4 align="center" id="op">Selamat Datang, Ini adalah halaman Admin <em>SMK YPS Samarinda.</em></h4>